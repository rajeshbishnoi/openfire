--
-- Database: `openfire`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `login_username` varchar(30) NOT NULL,
  `login_email` varchar(40) NOT NULL,
  `login_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `login_username`, `login_email`, `login_password`) VALUES
(1, 'rajesh', 'rajesh@gmail.com', 'rajesh'),
(3, 'user', 'user@gmail.com', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_username` varchar(30) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_type` varchar(15) NOT NULL DEFAULT 'Student',
  `user_usefor` varchar(100) NOT NULL,
  `user_remark` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_status` varchar(10) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_username`, `user_email`, `user_password`, `user_type`, `user_usefor`, `user_remark`, `created_at`, `user_status`) VALUES
(9, 't500', 't1000', 't101@gmail.coom', 'kjfdskf', 'other', '', '', '2017-07-23 07:19:59', 'Disapprove'),
(10, 't1000', 't500', 't500@gmail.com', 't500', 'other', '', '', '2017-07-23 07:20:03', 'Disapprove'),
(11, '', 't200', 't200@gmail.com', '1300', 'other', '', '', '2017-07-23 12:08:32', 'Approved'),
(12, '', 'tt550', 'tt550@gmail.com', 'tt500', 'other', '', '', '2017-07-23 20:38:39', 'Approved'),
(13, '', 'tttt', 'tttt@gmail.com', 'tttt', 'other', '', '', '2017-07-24 05:28:50', 'Pending'),
(14, '', 'tttttt', 'ttttttt@gmail.com', 'ttttttt', 'other', '', '', '2017-07-24 05:29:26', 'Pending'),
(15, '', 'ppppp', 'pppp@gmail.com', 'ppppp', 'other', '', '', '2017-07-24 05:30:41', 'Pending'),
(16, '', 'fdfsfsd', 'fsddf@gmail.com', 'fdsffds', 'other', '', '', '2017-07-24 05:31:01', 'Pending'),
(17, '', 'fdfsfsdfjdsjfl', 'jflds@gmail.com', 'jjasflsjl', 'other', '', '', '2017-07-23 20:38:51', 'Approved'),
(18, '', 'fdfsfsdfjdsjfljfdsojf', 'jfsdl@gmail.com', 'jdslfjlsj', 'other', '', '', '2017-07-24 05:31:23', 'Pending'),
(19, '', 'fsojf', 'jfsl@gmail.com', 'djsfkls', 'other', '', '', '2017-07-24 05:31:37', 'Pending'),
(20, '', 'rajesh', 'raj@gmail.com', 'fjsd', 'other', '', '', '2017-07-24 05:48:43', 'Pending'),
(21, 'dfsjljsa', 'fdjsk', 'dssdfk@gmda.com', '', 'other', '', '', '2017-07-24 05:50:20', 'Pending'),
(22, 'prem', 'prem', 'prem@gmail.com', '', 'other', '', '', '2017-07-24 05:54:58', 'Pending'),
(23, 'ram', 'ram', 'ram@gmail.com', '', 'other', 'rama', '', '2017-07-24 05:55:42', 'Pending'),
(24, 'rajj', 'rajj', 'rajj@gmail.com', '', 'other', 'rajjjjjj', 'jjjjjjjj', '2017-07-24 05:59:49', 'Pending'),
(25, 'terer', 'terer', 'ererw@yahoo.com', '', 'other', 'twerw', 'werewr', '2017-07-25 00:18:24', 'Pending'),
(26, 'rajsesj', 'jfalksd', 'jfassdjkl@gmail.com', '', 'other', 'jfkladsf', 'jkfldsja;', '2017-07-25 00:26:25', 'Pending'),
(27, 'name', 'neme', 'name@gmail.com', '', 'other', 'jfsdnak', 'jnenmn', '2017-07-25 00:29:07', 'Pending'),
(28, 'email', 'email', 'email@gmail.com', '', 'other', 'email.', 'email', '2017-07-25 00:30:02', 'Pending'),
(29, 'passs', 'pass', 'passs@gmai.com', 'passs', 'other', 'paxsss', 'passs', '2017-07-25 00:32:36', 'Pending'),
(30, 'pass', 'fjeds', 'rajeshshhs@gmailc.com', '', 'other', 'jflka', '', '2017-07-25 00:34:02', 'Pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
